//
//  miContacto.swfit.swift
//  Agenda
//
//  Created by Mac13 on 15/11/20.
//  Copyright © 2020 daniela_villa. All rights reserved.
//

import Foundation

struct miContacto{
    var nombre: String?
    var apellido: String?
    var telefono: Int64?
    var correo: String?
    var dirección: String?
    var foto: Data?
}
